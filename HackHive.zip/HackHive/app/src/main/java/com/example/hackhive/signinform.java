package com.example.hackhive;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class signinform extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signinform);
    }
    EditText name = (EditText) findViewById(R.id.names);
    String fullName = name.getText().toString();
    EditText Schoolcollege = (EditText) findViewById(R.id.Schoolcollege);
    String schoolcollege = Schoolcollege.getText().toString();
}